import React, { useState } from 'react';
import {
  ArrowLeft,
  FlaskConical,
  Microscope,
  Power,
  Ruler,
} from 'lucide-react';
import { Badge } from '@astryxdesign/core/Badge';
import { Banner } from '@astryxdesign/core/Banner';
import { Button } from '@astryxdesign/core/Button';
import { Card } from '@astryxdesign/core/Card';
import { Collapsible } from '@astryxdesign/core/Collapsible';
import { Divider } from '@astryxdesign/core/Divider';
import { Grid } from '@astryxdesign/core/Grid';
import { Heading } from '@astryxdesign/core/Heading';
import { HStack } from '@astryxdesign/core/HStack';
import { IconButton } from '@astryxdesign/core/IconButton';
import { List, ListItem } from '@astryxdesign/core/List';
import { NumberInput } from '@astryxdesign/core/NumberInput';
import { Selector } from '@astryxdesign/core/Selector';
import { Text } from '@astryxdesign/core/Text';
import { VStack } from '@astryxdesign/core/VStack';
import { GOLDEN_RESEARCH_CLIPS, PANACEA_SEMEN_KITS } from '../../data/panaceaCatalogs';
import { usePanacea } from '../../store/PanaceaContext';
import type { PipelineStageCode, SemenSessionRun, SubView } from '../../types/panacea';

interface SemenPreScreenViewProps {
  onBack: () => void;
  onOpenSubView: (view: SubView) => void;
}

const FAULT_STAGES: Array<{ value: string; label: string }> = [
  { value: 'NONE', label: 'None (Normal Pipeline)' },
  { value: 'S1', label: 'S1 · Missing Calibration -> Unclear' },
  { value: 'S2', label: 'S2 · Incomplete SHA-256 Upload' },
  { value: 'S3', label: 'S3 · Quarantine Stream Rejected' },
  { value: 'S5', label: 'S5 · Server Quality Gate Fail' },
  { value: 'S6', label: 'S6 · Elevated Debris Flagged' },
  { value: 'S7', label: 'S7 · Detection Model Disagreement' },
  { value: 'S10', label: 'S10 · Fallback -> Never Green' },
];

export const SemenPreScreenView: React.FC<SemenPreScreenViewProps> = ({
  onBack,
  onOpenSubView,
}) => {
  const { state, language, refreshState, toggleConsent, toggleFeatureFlags } = usePanacea();
  const isAr = language === 'ar';

  const [selectedKitId, setSelectedKitId] = useState(PANACEA_SEMEN_KITS[0].kitId);
  const [selectedGoldenId, setSelectedGoldenId] = useState(GOLDEN_RESEARCH_CLIPS[0].id);
  const [abstinenceDays, setAbstinenceDays] = useState(3);
  const [tempNote, setTempNote] = useState<'room' | '37c_stage'>('37c_stage');
  const [completeness, setCompleteness] = useState<'full' | 'partial'>('full');
  const [injectFault, setInjectFault] = useState<string>('NONE');
  const [calibrationStatus, setCalibrationStatus] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  const selectedKit =
    PANACEA_SEMEN_KITS.find((k) => k.kitId === selectedKitId) || PANACEA_SEMEN_KITS[0];
  const selectedGolden =
    GOLDEN_RESEARCH_CLIPS.find((g) => g.id === selectedGoldenId) || GOLDEN_RESEARCH_CLIPS[0];

  const killSwitchActive = Boolean(state?.featureFlags.homeResearchKillSwitch);
  const semenConsent = Boolean(state?.consents.semen_media?.state);
  const latestRun: SemenSessionRun | null = state?.semenSessions[0] || null;

  const handleCalibrateRuler = async (lines: number) => {
    const resp = await fetch('/v1/semen/calibration', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        detectedLinesCount: lines,
        spacingVariancePct: lines >= 8 ? 1.2 : 4.5,
        fieldWidthUm: selectedKit.fieldWidthUmDefault,
      }),
    });
    const data = await resp.json();
    setCalibrationStatus(
      data.ok
        ? isAr
          ? `نجحت المعايرة: ${data.umPerPx} µm/px (${data.linesDetected} خطوط)`
          : `Micrometer Verified: ${data.umPerPx} µm/px (${data.linesDetected} even lines)`
        : isAr
          ? data.messageAr
          : data.messageEn
    );
    await refreshState();
  };

  const handleRunPipeline = async () => {
    setRunning(true);
    try {
      const resp = await fetch('/v1/semen/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: `ses_${Date.now()}`,
          setupType: selectedKit.type,
          kitProfile: selectedKit,
          sampleMeta: {
            abstinenceDays,
            collectedAtIso: new Date().toISOString(),
            temperatureNote: tempNote,
            completeness,
            sampleName: selectedGolden.labelEn,
          },
          clips: selectedGolden.clips,
          isDemo: true,
          demoAttribution: 'Golden Research Fixture',
          injectFaultStage: injectFault === 'NONE' ? null : (injectFault as PipelineStageCode),
        }),
      });
      if (resp.ok) {
        await refreshState();
      }
    } finally {
      setRunning(false);
    }
  };

  return (
    <VStack gap={5}>
      <HStack gap={3} vAlign="center" hAlign="between">
        <HStack gap={3} vAlign="center" className="min-w-0">
          <IconButton
            label={isAr ? 'رجوع' : 'Back'}
            icon={<ArrowLeft className="w-4 h-4 rtl:rotate-180" />}
            variant="secondary"
            size="sm"
            onClick={onBack}
          />
          <div className="min-w-0">
            <Heading level={1}>
              {isAr ? 'الفحص المنزلي الأولي' : 'Home Pre-Screen Pipeline'}
            </Heading>
            <Text type="supporting" color="accent" weight="semibold">
              {isAr ? 'وضع بحثي فقط · جودة التصوير' : 'Research Mode Only · Quality Gate'}
            </Text>
          </div>
        </HStack>

        <Button
          size="sm"
          variant={killSwitchActive ? 'destructive' : 'secondary'}
          icon={<Power className="w-3.5 h-3.5" />}
          label={killSwitchActive ? 'KILL: ON' : 'Kill Switch'}
          onClick={() => toggleFeatureFlags({ homeResearchKillSwitch: !killSwitchActive })}
        />
      </HStack>

      <Banner
        status="warning"
        title={isAr ? 'واجهة المريض خالية من الأرقام' : 'Strict Zero-Numeric Patient Output'}
        description={
          isAr
            ? 'لا يعرض هذا القسم أرقاماً تقديرية للحيوانات المنوية أو أي نتيجة مطمئنة في واجهة المريض حتى استيفاء التحقق السريري والتنظيمي في الإمارات.'
            : 'Patient-facing view displays Capture Quality Feedback and Lab Routing ONLY. Numeric sperm counts, motility %, morphology, and patient bands remain disabled pending UAE clinical validation.'
        }
      />

      {!semenConsent && (
        <Banner
          status="info"
          title={
            isAr ? 'إذن معالجة فيديو الفحص المنزلي متوقف' : 'Home video consent (semen_media) is OFF'
          }
          endContent={
            <Button
              size="sm"
              variant="primary"
              label={isAr ? 'تفعيل' : 'Enable'}
              onClick={() => toggleConsent('semen_media', true)}
            />
          }
        />
      )}

      {/* Setup & Calibration Controls */}
      <Card padding={4} elevation="low">
        <VStack gap={4}>
          <Selector
            label={isAr ? '١. طقم العدسة والشريحة' : '1. Optical Setup & Fixed-Depth Chamber'}
            value={selectedKitId}
            onChange={setSelectedKitId}
            options={PANACEA_SEMEN_KITS.map((k) => ({ value: k.kitId, label: k.kitName }))}
          />

          <Card variant="muted" padding={3}>
            <VStack gap={2}>
              <HStack gap={2} vAlign="center" hAlign="between" wrap="wrap">
                <HStack gap={1.5} vAlign="center">
                  <Ruler className="w-4 h-4 text-[var(--color-accent)]" />
                  <Text weight="semibold">
                    {isAr ? 'معايرة المسطرة الميكرومترية' : 'Micrometer Ruler Calibration'}
                  </Text>
                </HStack>
                <HStack gap={2}>
                  <Button
                    size="sm"
                    variant="secondary"
                    label={isAr ? 'فحص ١٠ خطوط' : 'Pass (10 lines)'}
                    onClick={() => handleCalibrateRuler(10)}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    label={isAr ? 'فشل (<٨)' : 'Fail (<8)'}
                    onClick={() => handleCalibrateRuler(4)}
                  />
                </HStack>
              </HStack>
              {calibrationStatus && (
                <Text type="supporting" color="accent" weight="medium">
                  {calibrationStatus}
                </Text>
              )}
            </VStack>
          </Card>

          <Grid columns={{ minWidth: 130, max: 3 }} gap={2}>
            <NumberInput
              label={isAr ? 'أيام الامتناع' : 'Abstinence (days)'}
              min={1}
              max={14}
              isIntegerOnly
              value={abstinenceDays}
              onChange={(v) => setAbstinenceDays(v || 3)}
            />
            <Selector
              label={isAr ? 'درجة الحرارة' : 'Stage Temp'}
              value={tempNote}
              onChange={(v) => setTempNote(v as 'room' | '37c_stage')}
              options={[
                { value: '37c_stage', label: '37 °C Stage' },
                { value: 'room', label: 'Room Temp' },
              ]}
            />
            <Selector
              label={isAr ? 'اكتمال العينة' : 'Completeness'}
              value={completeness}
              onChange={(v) => setCompleteness(v as 'full' | 'partial')}
              options={[
                { value: 'full', label: 'Full sample' },
                { value: 'partial', label: 'Partial' },
              ]}
            />
          </Grid>

          <Selector
            label={
              isAr
                ? '٢. عينة الاختبار المرجعية (٥ حقول × ١٠ ثوانٍ)'
                : '2. Golden Capture Clip Fixture (5 Fields · SHA-256)'
            }
            value={selectedGoldenId}
            onChange={setSelectedGoldenId}
            options={GOLDEN_RESEARCH_CLIPS.map((g) => ({
              value: g.id,
              label: isAr ? g.labelAr : g.labelEn,
            }))}
          />

          <Selector
            label={
              isAr
                ? '٣. حقن الأعطال الاختياري (S0–S13)'
                : '3. Fault Injection Test (S0–S13 Stage Resilience)'
            }
            value={injectFault}
            onChange={setInjectFault}
            options={FAULT_STAGES}
          />

          <Button
            variant="primary"
            width="100%"
            isLoading={running}
            icon={<Microscope className="w-4 h-4" />}
            label={
              isAr
                ? 'تشغيل فحص الجودة والمراحل (S0–S13)'
                : 'Run Capture Quality Gate & S0–S13 Trace'
            }
            onClick={handleRunPipeline}
          />
        </VStack>
      </Card>

      {/* Patient-Facing Result Surface (ZERO numeric sperm values) */}
      {latestRun && (
        <Card padding={4} elevation="low">
          <VStack gap={3}>
            <HStack gap={2} vAlign="center" hAlign="between" wrap="wrap">
              <Badge
                label={
                  isAr
                    ? 'نتيجة واجهة المريض (خالية من الأرقام)'
                    : 'PATIENT-FACING OUTPUT (NUMERIC-FREE)'
                }
                variant="info"
              />
              <Badge
                label={latestRun.state}
                variant={latestRun.state === 'Completed' ? 'success' : 'warning'}
              />
            </HStack>

            <Banner
              status={latestRun.state === 'Completed' ? 'info' : 'warning'}
              title={latestRun.state}
              description={isAr ? latestRun.qualitySummaryAr : latestRun.qualitySummaryEn}
            />

            <Button
              variant="primary"
              width="100%"
              icon={<FlaskConical className="w-4 h-4" />}
              label={
                isAr ? 'حجز تحليل السائل المنوي في المختبر' : 'Book Diagnostic Lab Test (Signed Result)'
              }
              onClick={() => onOpenSubView('lab-booking')}
            />

            <Divider />

            <Collapsible
              trigger={
                isAr
                  ? 'عرض سجل البحث المقيد (S0–S13)'
                  : 'Research-Only Trace & Stage Inspector (S0–S13)'
              }
              defaultIsOpen={false}
            >
              <VStack gap={3} className="pt-2">
                <Text type="supporting" color="accent" weight="bold">
                  RESEARCH MODE ONLY — NOT A DIAGNOSTIC RESULT
                </Text>
                <HStack gap={2} wrap="wrap">
                  <Badge
                    label={`Conc Band (Research): ${latestRun.researchOnlyBandConc}`}
                    variant="neutral"
                  />
                  <Badge
                    label={`Motility Band (Research): ${latestRun.researchOnlyBandMotility}`}
                    variant="neutral"
                  />
                  <Badge label={`Model: ${latestRun.modelVersion}`} variant="neutral" />
                </HStack>

                {latestRun.couldNotUseItems.length > 0 && (
                  <Banner
                    status="warning"
                    title="Fallbacks Triggered"
                    description={latestRun.couldNotUseItems.join('; ')}
                  />
                )}

                <Card variant="muted" padding={0}>
                  <List hasDividers density="compact" edge="bleed">
                    {latestRun.stageLogs.map((s) => (
                      <ListItem
                        key={s.stage}
                        label={`${s.stage} · ${s.name}`}
                        description={s.note}
                        endContent={
                          <Badge
                            label={s.outcome.toUpperCase()}
                            variant={
                              s.outcome === 'passed'
                                ? 'success'
                                : s.outcome === 'fallback'
                                  ? 'warning'
                                  : 'error'
                            }
                          />
                        }
                      />
                    ))}
                  </List>
                </Card>
              </VStack>
            </Collapsible>
          </VStack>
        </Card>
      )}
    </VStack>
  );
};
