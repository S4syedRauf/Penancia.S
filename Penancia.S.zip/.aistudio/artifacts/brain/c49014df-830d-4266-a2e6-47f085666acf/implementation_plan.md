# Panacea — Full-Stack Production Architecture & Adaptation Plan

Transforms the existing mobile-first application shell into **Panacea** (*Developed with love by Syed*): a private, bilingual (English / Arabic RTL) Dubai-first men’s reproductive-health platform combining adaptive intake, deterministic safety routing, a flexible 74-day habit plan, a verified Report Vault with mandatory review, an end-to-end 5 km lab booking & Partner Staff Portal state machine, a research-mode Home Pre-Screen quality pipeline, and a constrained server-side Ask assistant—while keeping the exact existing visual design system, component structure, and bottom navigation tab names (`Diary`, `Activity`, `Meals`, `Profile`, `Pro`).

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The decisions below incorporate your Phase 1 selections and Panacea’s non-negotiable clinical, privacy, and partner-safety rules.

- **Confirmed Decision 1 — Full End-to-End Scope**: Implement the complete Panacea functional stack across Phases 1–3 and operational pilot controls (server-backed persistence, idempotency, transactional outbox, Partner Staff Portal, OCR extraction + mandatory review, Home Pre-Screen S0–S13 quality trace, and data export/deletion), while visibly marking external lab partner endpoints, payment confirmation, and home CASA interpretation with their required regulatory/simulation disclosures.
- **Confirmed Decision 2 — Exact Visual Layout & Original Tab Names**: Keep the exact white/lavender/purple (`#7955E8`) visual design system, component layouts, and the five floating black bottom navigation tabs (`Diary`, `Activity`, `Meals`, `Profile`, `Pro`), mapping every Panacea feature cleanly inside those views and modals.
- **Confirmed Decision 3 — Live English & Arabic RTL Switching**: Provide a persistent language toggle (`EN` / `AR`) that switches `dir="rtl"`, mirrors directional navigation icons, preserves mixed Arabic/Latin clinical units cleanly, and translates all UI copy, questionnaire blocks, routing explanations, and safety alerts.
- **Confirmed Decision 4 — Hybrid Constrained Ask Assistant**: Run the Ask router server-side using `@google/genai` (`gemini-4-hydrogen`) guarded by an emergency pre-router, consent gate (`reports_ai`), read-only tool context, and a deterministic post-validator with automatic fallback to clinically reviewed templates.
- **Open Operational Gates Preserved Honestly**: Live UAE lab contracts, real payment settlement, and validated consumer home-video diagnostic bands remain cleanly gated behind feature flags and kill switches until signed clinical/regulatory/partner approvals exist.

---

## 1. Overview & Core Concept

- **What It Does**: Connects a user privately from uncertainty to verified action in one cohesive workflow:
  1. **Private Onboarding & Consent Centre**: Random server-generated alias, optional recovery warning, Discreet Mode, and 9 independent purpose-bound consents enforced on both API requests and queued jobs.
  2. **Adaptive 26-Question Intake & Emergency Bypass**: Five-block questionnaire supporting *Prefer not to say*, *Not sure*, pause/resume, and edits; an offline-ready conservative emergency trigger table interrupts immediately for urgent symptoms (e.g., sudden severe testicular pain) ahead of any booking or commerce.
  3. **Deterministic Routing & Test Basket**: Versioned rules route to Self-Care, Primary Care, Andrology/Urology, or Urgent Care with explicit *what was used* and *what remains unknown*. Only **Semen Analysis** is initially bookable; users can mark prior tests done and attach reports without forced upsells.
  4. **Flexible Habit Plan (`30 / 40 / 60 / 74 Recommended / 90 / Custom`)**: Effort-only **Plan Consistency** (`completed / scheduled`) with paused-day exclusion, explicit non-health disclaimer, Day 74 checkpoint, and optional 15-day continuation that never suppresses or delays a clinician-recommended retest.
  5. **Report Vault & Mandatory Confirmation**: Quarantine upload check, header PII masking guidance, rule-based + Gemini structured OCR draft extraction, side-by-side user confirmation (`ai_value` vs `user_value` with provenance), versioned corrections, Direction View, and selective Clinician Summary export.
  6. **Dubai-First Lab Booking (5.000 km Rule), Partner Staff Portal & Stay Alert**: Server-side Haversine eligibility check (`<= 5.000 km` + partner capability + handling window + capacity = Home Collection; otherwise Centre Slot), explicit field-level Consent Pack preview, idempotent checkout, full Specimen State Machine, an isolated Partner Staff Portal session to process/reject/recollect/release signed reports, and human-owned Stay Alert tasks for critical results.
  7. **Home Semen Pre-Screen (Research Mode)**: Optics/chamber setup check, micrometer calibration verification, live/simulated capture quality gate, resumable SHA-256 chunked upload simulation, S0–S13 server pipeline trace, zero patient-facing numeric leakage (`assertNoPipelineNumericLeakage`), and a server kill switch.
- **Target Audience**: Men in Dubai and the broader UAE seeking a private, low-friction, culturally respectful first step for reproductive health, alongside authorized partner lab staff managing assigned specimen workflows.
- **Key Value**: Eliminates ungrounded AI guesswork and fragmented clinic steps by uniting deterministic safety routing, verified report provenance, and auditable lab handoff inside a calm mobile-first interface.

---

## 2. User Experience & Visual Design

### Visual Identity & Theme
- **Aesthetic Direction**: Clean, calm, high-trust medical-wellness mobile UI preserving 100% of the existing visual hierarchy, spacing, corner radii (`16px–24px`), hairline borders (`#EEEEF2`), soft lavender highlights (`#F6F3FF`), and floating black pill bottom navigation (`#111114` dock with `#7955E8` active pill).
- **Color Tokens**: Primary Purple `#7955E8`, Secondary Lavender `#B9A4F5`, Light Lavender `#F6F3FF`, Surface White `#FFFFFF`, Neutral Grey `#F5F5F7`, Primary Text `#171717`, Muted Text `#858585`, Positive Green `#82B52F`, Caution Amber `#F5A92F`. Color is always paired with explicit text and icon labels (never hue-only state).
- **Typography & RTL**: `Plus Jakarta Sans` paired with `tabular-nums` for all metrics, dates, distances, and lab values; full bidirectional (`LTR` / `RTL`) layout mirroring with clean numeric isolation for clinical units.
- **Discreet & Offline Safety**: Discreet Mode neutralizes visible terminology on primary surfaces and notifications; emergency urgent-care instructions remain cached locally and accessible offline before sign-in.

### Navigation & Key User Flows (Preserving Original Tab Names)

| Original Tab | Panacea Workspace Inside | Key Interactive Workflows |
|---|---|---|
| **Diary** *(Landing)* | **Today Dashboard & Core Hub** | Discreet header (Alias, EN/AR switch, Search/`Ask` agent, Stay Alert bell) · Double-row semicircular **Plan Consistency** gauge (`15/20 = 75%` + explicit effort-only disclaimer) + `Details` (**Direction View**) · 3 Metric Cards (**Plan**, **Screening Pathway**, **Stay Alert**) · 4 Action Cards (**Health Check 26-Q**, **Report Vault**, **Lab Booking (5km)**, **Home Pre-Screen**) |
| **Activity** | **Plan Timeline, Symptoms & Habits** | 7-day `WeeklyCalendar` & full month picker · Vertical hourly `ActivityTimeline` for scheduled **Plan Actions**, **Symptom Tracker**, **Wearable Sleep/HR/Activity**, and **Confirmed Lab/Pickup Events** · Complete/Skip/Pause actions · `History` (**Direction View & Gated IIEF-5/PHQ-2 Check-Ins**) |
| **Meals** | **Nutrition, Test Catalog & Library** | Segmented switcher: **Nutrition & Noon List** (reviewed allergy-aware meals, copyable Noon UAE search list with Auto-Order disabled badge) and **Tests & Health Library** (Semen Analysis catalog + Test Basket, reviewed `Health Library`, `Know Your Normal`, `Life Stages`) |
| **Profile** | **Identity, Consents, Partner & Data** | Avatar ring (plan/setup completion) + Random Alias (`Panacea`) + `Active` badge · 2×2 Grid (**Language EN/AR**, **Plan 30–90d**, **Dubai Area / 5km**, **Discreet Mode**) · Primary rows (**Wearable Connectors**, **Stay Alert & Notifications**) · **Consent Centre** (9 toggles), **Partner Staff Portal**, **Lab Self-Registration Queue**, **Data Export (JSON/CSV)**, **Delete My Data**, **Redacted Audit Log** |
| **Pro** | **Open Access Care, Ask & Emergency** | Clearly communicates zero paywall on clinical/safety features · Direct launchpads for **Constrained Ask Assistant**, **Emergency 998 Bypass**, **Booking & Specimen Tracker**, and **Lab Partner Onboarding** |

### Interactive Feedback & States
- Every upload, booking transition, pipeline stage, and AI call displays explicit `Idle -> Processing -> Confirmed / NeedsReview / Fallback / Error` states, retry actions, and reduced-motion-safe transitions (`<= 200ms` micro-interactions).
- Pending care actions in **Stay Alert** always display: what is known, what is unknown, last confirmed partner timestamp, named human owner, and a persistent escalation path that cannot be closed by push delivery or patient read receipts alone.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Modular Monolith Backend + Atomic Persistent Store**:
  - *Chosen Approach*: Express API (`server.ts`) backed by a persistent atomic JSON/transactional store on disk with an explicit `OutboxMessage` queue, `IdempotencyRecord` table, and separate patient vs. partner-staff session scopes.
  - *Why*: Delivers true end-to-end multi-session persistence (a user booking an order in the Patient session can immediately process it in the Partner Staff Portal and see confirmed updates return to the Patient timeline) without requiring external cloud provisioning.
  - *Alternatives Considered*: Browser-only `localStorage` (cannot isolate server secrets, partner staff roles, or Gemini API calls) or external SQL provisioning (unnecessary setup friction for immediate full-stack execution).
- **Decision 2 — Deterministic Clinical & Geographic Rules Separate from AI**:
  - *Chosen Approach*: Keep emergency detection, 26-question routing, 5.000 km Haversine distance checks, plan consistency math, and report confirmation strictly deterministic on client/server engines; restrict Gemini (`gemini-4-hydrogen`) solely to server-side `Ask` explanation (with post-validation and template fallback) and draft OCR structuring.
  - *Why*: Guarantees safety-critical logic works offline, deterministically, and without hallucination or numeric leakage.
- **Decision 3 — Strict Visual Shell Continuity**:
  - *Chosen Approach*: Reuse the exact existing screen wrappers, card geometries, circular icon styles, semicircular gauge, timeline rail, 2×2 grid, and 5-tab floating black bottom bar, adapting labels and modals cleanly inside them.
  - *Why*: Directly satisfies your requirement to keep the interface, components, pages, and tab names intact while powering every Panacea capability.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                    Bilingual Mobile-First UI (EN / AR RTL)              │
│  Floating Black Bottom Nav: [ Diary | Activity | Meals | Profile | Pro ]│
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌────────────────┐  │
│  │ Diary (Today)│ │ Activity     │ │ Meals        │ │ Profile & Pro  │  │
│  │ • Consistency│ │ • 7-Day Cal  │ │ • Nutrition  │ │ • Consent Ctr  │  │
│  │ • 3 Pillars  │ │ • Timeline   │ │ • Noon Links │ │ • Partner Desk │  │
│  │ • 4 Journeys │ │ • Symptoms   │ │ • Test Cat.  │ │ • Export/Delete│  │
│  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ └───────┬────────┘  │
└─────────┼────────────────┼────────────────┼─────────────────┼───────────┘
          │                │                │                 │
          └────────────────┴────────┬───────┴─────────────────┘
                                    ▼  HTTPS + Role/Consent + Idempotency-Key
┌─────────────────────────────────────────────────────────────────────────┐
│                Express Modular Backend (server.ts)                      │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────────────┐ │
│  │ Clinical & Plan  │ │ Partner & Order  │ │ Quarantine, OCR & CASA   │ │
│  │ • 26-Q + Rules   │ │ • 5.000 km Gate  │ │ • MIME/Size/Scan Check   │ │
│  │ • 74-Day Engine  │ │ • Booking Saga   │ │ • Rule + Gemini Draft OCR│ │
│  │ • Stay Alert     │ │ • Staff Portal   │ │ • S0-S13 CV Trace & Kill │ │
│  └────────┬─────────┘ └────────┬─────────┘ └────────────┬─────────────┘ │
│           │                    │                        │               │
│  ┌────────▼────────────────────▼────────────────────────▼─────────────┐ │
│  │  Constrained Ask Router (/v1/ask)                                  │ │
│  │  Urgent Keywords ─▶ Consent Check ─▶ Scoped Context ─▶ Gemini 4    │ │
│  │  (Offline Bypass)   (reports_ai)    (Confirmed Only)   + Validator │ │
│  └─────────────────────────────────┬──────────────────────────────────┘ │
│                                    ▼                                    │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │  Persistent Transactional Store + Outbox + Redacted Audit Log      │ │
│  └────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **Identity & Consent**: `UserProfile` (server random alias, EN/AR locale, Discreet Mode, Dubai district coordinates, plan duration `30|40|60|74|90|custom`), `ConsentRecord` (9 independent keys with version & timestamp), `ShareGrant` (named partner, exact field list, expiry, revocation).
- **Clinical & Plan**: `QuestionnaireResponse` (26 questions + conditional follow-ups, *Prefer not to say* / *Not sure* / *Unknown* preserved distinctly), `ScreeningRun` (versioned rule trace, pathway, used/missing items), `PlanAction` & `PlanCheckIn` (complete/skip/pause, local date, consistency numerator/denominator), `SymptomEvent`, `WearableMetric` (read-only sleep, steps, HR, HRV, `null` when unavailable).
- **Reports & Home Research**: `VaultReport` (`Quarantined -> NeedsReview -> Confirmed -> Summarised`, `aiValue` vs `userValue`, versioned corrections, masked header indicators), `SemenSessionRun` (setup profile, calibration `umPerPx`, quality gate checks, S0–S13 `StageLogEntry`, research-only status, zero leaked numeric outputs).
- **Care, Partner & Governance**: `Order` (full Specimen Order State Machine from `Draft` through `ReportReady` plus `SpecimenRejected` / `RecollectionRequested`), `ConsentPack`, `FollowUpTask` (human owner, acknowledgement vs. completion), `PartnerApplication` (restricted self-registration queue), `AuditEvent` (strictly redacted, zero PHI/tokens/health metrics).

### Interactive Component & State Mapping
- **Plan Consistency Gauge & Metric Cards**: Selecting plan duration (`30/40/60/74/90/custom`), toggling daily actions, pausing a day, or extending `+15 days` at Day 74 recalculates `completed / eligible` in real time without altering clinical screening or hiding due retests.
- **26-Question Intake & Emergency Bypass**: Selecting any urgent trigger (`Q1–Q4` sudden pain, swelling, injury, blood) immediately interrupts the flow offline and displays UAE 998 urgent care guidance; completing/editing other answers triggers `evaluateDeterministicScreening` and updates the Test Basket and Pathway card.
- **5 km Lab Booking & Partner Portal Loop**: Changing the user's Dubai pin/district dynamically evaluates server-side distance to the verified Dubai lab site (`<= 5.000 km` enables Home Collection when capacity & handling window pass; `> 5.000 km` restricts to Centre Slots). Previewing and approving the `ConsentPack` submits an idempotent `POST /v1/orders` request. Switching into the **Partner Staff Portal** allows authorized staff to scan the opaque ticket, record `Collected -> Received -> Accepted -> Processing -> ReportReady` (rejecting duplicate/out-of-order regressions), upload a signed fixture report, or reject/request recollection—updating the Patient timeline and **Stay Alert** immediately.
- **Report Vault & Ask Grounding**: Uploading a report runs quarantine/file validation, extracts draft rows via rule-based parser + optional Gemini multimodal structuring, highlights rows for mandatory user review, and only unlocks `/v1/ask` explanations once confirmed and `reports_ai` consent is enabled.
- **Data Rights**: Exporting generates downloadable JSON and multi-tab CSV/Excel-compatible workbooks (`Daily Summary`, `Plan Actions`, `Symptoms`, `Reports Index`); deleting purges user data cleanly and records non-health audit completion with honest backup/partner-copy disclosures.
